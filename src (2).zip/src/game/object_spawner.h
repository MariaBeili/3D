#pragma once
#include "game/spawnableobject.h"
#include <vector>
#include <random>

// Gestiona tots els objectes i la seva aparici� segons la probabilitat i la posici� del jugador


class ObjectSpawner {
public:
    std::vector<SpawnableObject> object_types;
    std::vector<EntityMesh*> active_objects;

    ObjectSpawner();
    void init();
    void update(float dt, const Vector3& player_pos);
    void spawnObject(const SpawnableObject& type, const Vector3& player_pos);
    void cleanupPassedObjects(const Vector3& player_pos);
};

