#pragma once
#include "framework/entities/entity_mesh.h"
#include "graphics/shader.h"
#include "graphics/texture.h"

// Aquesta classe cont� la configuraci� de cada tipus d�objecte (freq��ncia, probabilitat, etc.)
struct SpawnableObject {
    std::string name;
    Mesh* mesh = nullptr;
    Material material;
    float spawn_interval = 5.0f; // segons entre aparicions
    float spawn_timer = 0.0f;
    float probability = 1.0f;    // 0.0 a 1.0
    float fall_speed = 20.0f;

    SpawnableObject(const std::string& name, const std::string& mesh_path, const std::string& tex_path, float interval, float prob, float speed) {
        this->name = name;
        this->mesh = Mesh::Get(mesh_path.c_str());
        if (!this->mesh) {
            this->mesh = new Mesh();
            this->mesh->createCube();
        }

        this->material.shader = Shader::Get("data/shaders/basic.vs", "data/shaders/texture.fs");
        this->material.diffuse = Texture::Get(tex_path.c_str());
        this->spawn_interval = interval;
        this->probability = prob;
        this->fall_speed = speed;
    }
};
