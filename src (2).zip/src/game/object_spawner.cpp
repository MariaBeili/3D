#include "object_spawner.h"
#include "game/world.h"
#include <iostream>

ObjectSpawner::ObjectSpawner() {}

void ObjectSpawner::init() {
    // Afegim objectes segons el document de disseny
    object_types.push_back(SpawnableObject("Jetpack", "data/jetpack/jetpack.obj", "data/jetpack/texture.png", 4.0f, 0.4f, 25.0f));
    //object_types.push_back(SpawnableObject("Obstacle", "data/scene/barrier_2x1x1_green/barrier_2x1x1_green.obj", "data/scene/barrier_2x1x1_green/platformer_texture.png", 2.5f, 0.6f, 20.0f));
    //object_types.push_back(SpawnableObject("Ring", "data/scene/platform_2x2x2_green/platform_2x2x2_green.obj", "data/scene/platform_2x2x2_green/platformer_texture.png", 6.0f, 0.3f, 18.0f));
}

void ObjectSpawner::update(float dt, const Vector3& player_pos) {
    for (auto& type : object_types) {
        type.spawn_timer += dt;

        if (type.spawn_timer >= type.spawn_interval) {
            if ((float)rand() / RAND_MAX <= type.probability) {
                spawnObject(type, player_pos);
            }
            type.spawn_timer = 0.0f;
        }
    }

    // Actualitza moviment dels objectes
    for (auto obj : active_objects) {
        if (!obj) continue;
        Vector3 pos = obj->model.getTranslation();
        pos.y -= 30.0f * dt; // caiguda global
        obj->model.setTranslation(pos);
    }

    cleanupPassedObjects(player_pos);
}

void ObjectSpawner::spawnObject(const SpawnableObject& type, const Vector3& player_pos) {
    Camera* cam = Camera::current;
    if (!cam) return;

    // Vector de direcci� de la c�mera (forward)
    Vector3 forward = cam->center - cam->eye;
    forward.normalize();

    // Dist�ncia davant del jugador dins de la visi� de la c�mera
    float distance = 30.0f;
    Vector3 spawn_pos = player_pos + forward * distance;

    // Vector "right" i "up" de la c�mera per dispersi� dins pantalla
    Vector3 right = cam->getLocalVector(Vector3(1, 0, 0));
    Vector3 up = cam->getLocalVector(Vector3(0, 1, 0));

    // Desviaci� aleat�ria controlada dins del frustrum visible
    spawn_pos += right * ((rand() % 10 - 5));  // dispersi� horitzontal
    spawn_pos += up * ((rand() % 6 - 3));  // lleugera dispersi� vertical

    // Crear l'objecte
    EntityMesh* obj = new EntityMesh(type.mesh, type.material, type.name);
    obj->model.setTranslation(spawn_pos);
    World::instance->myscene->addChild(obj);
    active_objects.push_back(obj);

    std::cout << "[SPAWN] Objecte " << type.name << " creat a (" 
              << spawn_pos.x << ", " << spawn_pos.y << ", " << spawn_pos.z << ")\n";
}

void ObjectSpawner::cleanupPassedObjects(const Vector3& player_pos) {
    auto& vec = active_objects;
    vec.erase(std::remove_if(vec.begin(), vec.end(), [&](EntityMesh* obj) {
        if (!obj) return true;
        float y = obj->model.getTranslation().y;
        // si el jugador ja ha passat per sobre
        float dist_to_player = obj->model.getTranslation().y - player_pos.y;
        if (dist_to_player > 30.0f)  // l'objecte ja ha quedat 30 unitats per sobre del player 
        {
            World::instance->destroyEntity(obj);
            return true;
        }
        return false;
    }), vec.end());
}

