// character.fs
varying vec3 v_position;
varying vec3 v_world_position;
varying vec3 v_normal;
varying vec2 v_uv;
varying vec4 v_color;

uniform vec4 u_color;       // multiplicador / tint global
uniform sampler2D u_texture;
uniform vec2 u_maps;        // x = has Kd texture (1.0) o no (0.0)
uniform vec4 u_Kd;          // color dif�s RGBA del material
uniform vec3 u_Ka;
uniform vec3 u_Ks;
uniform float u_time;

void main()
{
    vec4 baseColor = u_Kd;

    // si u_maps.x == 1.0 -> hi ha textura Kd, samplegem
    if (u_maps.x < 0.5) {
        // sense textura, usa Kd
     gl_FragColor = vec4(u_Kd.rgb, 1.0) * u_color;
    } else {
        vec4 tex = texture2D(u_texture, v_uv);
        gl_FragColor = tex * u_color;
    }
    // aplicar tint o multiplicador global
    baseColor *= u_color;

    // (Opcional) aplicar llums amb u_Ka, u_Ks i v_normal aqu� si necessites
    gl_FragColor = baseColor;
}

